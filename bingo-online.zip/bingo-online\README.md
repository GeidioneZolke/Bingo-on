# Bingo Online

Este projeto é uma aplicação de Bingo Online, desenvolvida como um protótipo educativo. Abaixo estão as informações sobre os arquivos que compõem o projeto e como utilizá-lo.

## Estrutura do Projeto

- `index.html`: Este arquivo é a estrutura principal da aplicação. Ele contém o layout do jogo de bingo, incluindo botões para sortear números, limpar a cartela e reiniciar o jogo. Também possui seções para exibir o último número sorteado e o histórico de números.

- `style.css`: Este arquivo contém os estilos CSS para a aplicação. Ele define a aparência visual do jogo, incluindo cores, fontes e layout dos elementos.

- `script.js`: Este arquivo contém a lógica do jogo. Ele implementa as funções para sortear números, gerar novas cartelas, limpar a cartela atual e gerenciar o histórico de números sorteados.

## Como Executar

1. **Clone o repositório** ou faça o download dos arquivos.
2. **Abra o arquivo `index.html`** em um navegador web.
3. **Interaja com a aplicação** utilizando os botões disponíveis para jogar Bingo.

## Aviso

⚠️ Este é um protótipo educativo. Não há apostas em dinheiro real.