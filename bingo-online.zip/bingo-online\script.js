// Este arquivo contém a lógica do jogo de bingo.

let numerosSorteados = [];
let intervaloAuto = null;

function sortearNumero() {
    if (numerosSorteados.length >= 75) {
        alert("Todos os números já foram sorteados!");
        return;
    }

    let numero;
    do {
        numero = Math.floor(Math.random() * 75) + 1;
    } while (numerosSorteados.includes(numero));

    numerosSorteados.push(numero);
    document.getElementById("ultimo").innerText = numero;
    atualizarHistorico();
    atualizarCartela(numero);
}

function autoSortear() {
    if (intervaloAuto) return;

    intervaloAuto = setInterval(sortearNumero, 1000);
}

function pararAuto() {
    clearInterval(intervaloAuto);
    intervaloAuto = null;
}

function novaCartela() {
    numerosSorteados = [];
    document.getElementById("ultimo").innerText = '';
    document.getElementById("historico").innerText = '';
    // Aqui você pode adicionar a lógica para gerar uma nova cartela
}

function limparCartela() {
    // Aqui você pode adicionar a lógica para limpar a cartela atual
}

function reiniciar() {
    pararAuto();
    novaCartela();
    // Aqui você pode adicionar a lógica para reiniciar o jogo
}

function atualizarHistorico() {
    document.getElementById("historico").innerText = numerosSorteados.join(', ');
}

function atualizarCartela(numero) {
    // Aqui você pode adicionar a lógica para atualizar a cartela com o número sorteado
}